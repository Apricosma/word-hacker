## word-hacker

Can you hack into the mainframe? Get above 60 score to successfuly break in
A simple but fun typing challenge. Developer record is 108 :)

[Challenge the firewall here!](https://apricosma.github.io/wordhack)