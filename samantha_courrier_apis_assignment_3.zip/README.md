## word-hacker

Can you hack into the mainframe? Get above 60 score to successfuly break in
A simple but fun typing challenge. Developer record is 108 :)


There is a fixed version inside of branch word-hack-fix, but I won't be merging it yet. 

[Challenge the firewall here!](https://apricosma.github.io/word-hacker)